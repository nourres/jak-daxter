#include <cstdlib>
#include "common/common_types.h"

u32 crc32(const u8* data, size_t size);