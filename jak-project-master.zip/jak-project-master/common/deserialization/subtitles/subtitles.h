#pragma once

#include "common/serialization/subtitles/subtitles.h"

bool write_subtitle_db_to_files(const GameSubtitleDB& db);
