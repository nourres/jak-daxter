#pragma once

constexpr int SECTOR_SIZE = 0x800;  // media sector size