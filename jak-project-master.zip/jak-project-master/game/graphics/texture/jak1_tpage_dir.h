#pragma once

#include <vector>
#include "common/common_types.h"

const std::vector<u32> get_jak1_tpage_dir();
constexpr u32 EXTRA_PC_PORT_TEXTURE_COUNT = 50;