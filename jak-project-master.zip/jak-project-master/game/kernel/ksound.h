#pragma once

/*!
 * @file ksound.h
 * There's not much here. My guess is this was set up as framework to match the kmachine.cpp format,
 * but whoever did the sound didn't use this.
 */

void InitSound();
void ShutdownSound();
void InitSoundScheme();
