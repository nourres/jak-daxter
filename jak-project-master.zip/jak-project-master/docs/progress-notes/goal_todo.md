Done (has documentation)
- `e`
- `:exit`
- `asm-file`, `m`, `ml`
- `listen-to-target`, `reset-target`, `:status`, `lt`, `r`

Done (needs documentation)
- `top-level`
- `begin`
- `seval`
- `#cond`, `#when`, `#unless`

- Macro System




Todo
- Type System
