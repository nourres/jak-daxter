#pragma once

namespace decompiler {
class Function;
void build_initial_forms(Function& function);
}  // namespace decompiler