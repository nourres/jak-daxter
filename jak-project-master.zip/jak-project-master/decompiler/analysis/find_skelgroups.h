#pragma once

#include "decompiler/Function/Function.h"
#include "decompiler/util/DecompilerTypeSystem.h"

namespace decompiler {
void run_defskelgroups(Function& top_level_func);
}
