#pragma once

#include "decompiler/Function/Function.h"

namespace decompiler {
void run_defpartgroup(Function& top_level_func);
}
