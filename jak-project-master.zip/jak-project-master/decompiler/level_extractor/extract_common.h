#pragma once
#include <vector>
#include "common/common_types.h"

u32 clean_up_vertex_indices(std::vector<u32>& idx);